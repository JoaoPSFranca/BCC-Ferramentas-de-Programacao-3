export const environment = {
  production: false,
  api: 'http://10.117.64.128:3000'
};
