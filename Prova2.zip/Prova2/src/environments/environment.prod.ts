export const environment = {
  production: true,
  api: 'http://10.117.64.128:3000'
};
