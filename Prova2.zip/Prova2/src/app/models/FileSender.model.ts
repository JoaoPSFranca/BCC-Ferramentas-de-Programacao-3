export interface FileSender {
    file: File,
    tags: string
}