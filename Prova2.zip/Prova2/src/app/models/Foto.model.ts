import { FileFoto } from "./FileFoto.model";

export interface Foto {
    file: FileFoto,
    tags: string
}